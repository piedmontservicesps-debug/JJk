'use client';
import { useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signInAnonymously, GoogleAuthProvider, signOut } from 'firebase/auth';
import { fb, hasConfig } from '../lib/firebase';
import { installPlatform } from '../lib/platform';
import { SHELL_HTML, SKY_HTML } from '../lib/shell';

let engineStarted = false;

export default function Game() {
  const [user, setUser] = useState(undefined); // undefined = checking, null = signed out
  const [error, setError] = useState('');

  useEffect(() => {
    if (!hasConfig) { setUser(null); return undefined; }
    return onAuthStateChanged(fb().auth, (u) => setUser(u || null));
  }, []);

  useEffect(() => {
    if (!user || engineStarted) return;
    engineStarted = true;
    installPlatform({ fs: fb().fs, user });
    import('../lib/game').then((m) => m.startGame());
  }, [user]);

  const signInGoogle = async () => {
    setError('');
    try { await signInWithPopup(fb().auth, new GoogleAuthProvider()); }
    catch (e) { setError(e && e.code === 'auth/popup-closed-by-user' ? 'Sign-in was closed. Try again.' : 'Couldn’t sign in with Google. Check that Google sign-in is turned on in Firebase.'); }
  };
  const signInGuest = async () => {
    setError('');
    try { await signInAnonymously(fb().auth); }
    catch { setError('Guest play is turned off. Turn on Anonymous sign-in in Firebase, or use Google.'); }
  };

  if (!hasConfig) {
    return (
      <>
        <div dangerouslySetInnerHTML={{ __html: SKY_HTML }} />
        <div className="lobby">
          <h1>November Pact</h1>
          <p className="hint">The database isn’t set up yet. Copy <code>.env.local.example</code> to <code>.env.local</code>, add your Firebase keys, and restart. The README walks through it.</p>
        </div>
      </>
    );
  }

  if (user === undefined) {
    return (
      <>
        <div dangerouslySetInnerHTML={{ __html: SKY_HTML }} />
        <div className="lobby"><p className="hint">Connecting…</p></div>
      </>
    );
  }

  if (!user) {
    return (
      <>
        <div dangerouslySetInnerHTML={{ __html: SKY_HTML }} />
        <div className="lobby">
          <h1>November Pact</h1>
          <p className="hint">Sign in so the room remembers you. Use the same Google account on every device to keep your progress.</p>
          <div className="signin-card">
            <button className="btn big" onClick={signInGoogle}>Sign in with Google</button>
            <button className="btn ghost" onClick={signInGuest}>Play as guest on this device</button>
            {error ? <p className="err" role="alert">{error}</p> : null}
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <div dangerouslySetInnerHTML={{ __html: SHELL_HTML }} />
      <button className="signout" onClick={() => signOut(fb().auth).then(() => window.location.reload())}>
        Sign out{user.isAnonymous ? ' (guest)' : ''}
      </button>
    </>
  );
}
