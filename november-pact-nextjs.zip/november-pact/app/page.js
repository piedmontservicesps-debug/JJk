'use client';
import dynamic from 'next/dynamic';

// The game runs only in the browser (audio, canvas, live database listeners).
const Game = dynamic(() => import('../components/Game'), { ssr: false });

export default function Page() {
  return <Game />;
}
