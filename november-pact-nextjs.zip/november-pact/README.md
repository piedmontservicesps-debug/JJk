# November Pact (Next.js)

A three-player season of spins, attacks and pixel sorcerers. This is the Next.js version of the
November Pact game. All game state lives in a shared Firebase (Cloud Firestore) database, so
every player sees the same room live on their own device.

## What is saved, and where

Everything is in **Cloud Firestore** in your Firebase project:

| Path | What it holds |
| --- | --- |
| `rooms/<CODE>` | Room settings: admin, week number, open/locked, started, wheel odds, challenges, shop items, ambient and sound settings |
| `rooms/<CODE>/players` | Each player: name, customized pixel sorcerer, ready status |
| `rooms/<CODE>/powers` | Weekly power spins |
| `rooms/<CODE>/rolls` | Weekly challenge spins and their status |
| `rooms/<CODE>/attacks` | Shop attacks and their status |
| `rooms/<CODE>/arsenal` | Techniques bought earlier |
| `rooms/<CODE>/ledger` | Every point and token change (totals are added up from this) |
| `rooms/<CODE>/feed` | The live feed history |
| `data/users/<uid>/me`, `.../prefs` | Your last room and your own sound and motion settings |

Refreshing, signing out and back in, or redeploying never wipes anything. Every screen listens
live, so an attack, an accept or an admin edit shows up for everyone within a second or two.

**A second device:** sign in with the same Google account and your room reopens by itself.
**A new player:** signs in, taps **Join room** and types the 5-character room code.

## Setup (about 10 minutes)

1. **Create a Firebase project** at https://console.firebase.google.com.
2. **Add a Web app** (Project settings → Your apps → `</>`). Copy the config values.
3. **Turn on sign-in:** Build → Authentication → Sign-in method → enable **Google**
   (and **Anonymous** if you want the "Play as guest" button).
4. **Create the database:** Build → Firestore Database → Create database (production mode).
5. **Paste the rules:** Firestore → Rules → replace with the contents of `firestore.rules` → Publish.
6. **Add your keys:** copy `.env.local.example` to `.env.local` and fill in the four values.
7. Run it:

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy (Vercel)

1. Push this folder to a GitHub repo and import it at https://vercel.com/new.
2. In the Vercel project → Settings → Environment Variables, add the same four
   `NEXT_PUBLIC_FIREBASE_*` values.
3. Deploy. Then in Firebase → Authentication → Settings → **Authorized domains**, add your
   Vercel domain (for example `november-pact.vercel.app`) so Google sign-in works there.

Share the site link with your two friends. One person creates a room; the others join with the code.

## Project layout

```
app/layout.js        page shell, fonts, viewport
app/page.js          loads the game in the browser only
app/globals.css      all styles (night-rooftop theme, animations)
components/Game.jsx  sign-in screen, then starts the game engine
lib/game.js          the game itself (rooms, lobby, spins, shop, board, admin, sounds, scenes)
lib/dbAdapter.js     Firestore adapter used by the engine
lib/platform.js      connects the engine to Firestore and the signed-in player
lib/firebase.js      Firebase setup from your .env.local values
firestore.rules      database access rules
```

## Notes

- The room creator is the admin (Admin tab: Edit Wheel, Edit Shop, Edit Challenges, Room controls).
- The five power rules are fixed in `lib/game.js` (`POWERS`).
- The rules let any signed-in player write to rooms, which keeps setup simple for a group of
  friends. Anyone with your site link and a Google account could create or join rooms.
