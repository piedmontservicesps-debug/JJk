/** @type {import('next').NextConfig} */
const nextConfig = {
  // The game engine manages its own DOM, so a second dev-mode mount would start it twice.
  reactStrictMode: false
};
export default nextConfig;
